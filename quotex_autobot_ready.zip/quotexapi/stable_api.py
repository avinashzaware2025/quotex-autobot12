class Quotex:
    def __init__(self, email, password):
        self.email = email
        self.password = password

    def login(self):
        # Dummy logic to simulate login success
        return True